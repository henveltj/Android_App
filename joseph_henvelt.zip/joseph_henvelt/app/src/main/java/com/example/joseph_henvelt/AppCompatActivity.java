package com.example.joseph_henvelt;

import android.os.Bundle;

public class AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
    }
}
