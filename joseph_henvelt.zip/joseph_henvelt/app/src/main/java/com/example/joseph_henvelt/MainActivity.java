package com.example.joseph_henvelt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.Toast;


/**
 * The MainActivity is the home screen of the app
 * It will display different buttons that the user can select
 * Only two buttons will bring the user to a new section
 *
 * @author  HEnvelt Joseph
 * @version 1.0
 */

public class MainActivity extends AppCompatActivity  {

    //Create the buttons
   // Button MSButton, DeptButton, GGButton, GCButton, ISButton, GDButton,WFUButton,CUButton, CartButton;

    //Create a Dummy String for sections of the app that are under construction
    private final String DUMMYMESSAGE = "This page is under construction";

    /**
     * onCreate will create the buttons when the app is first started or when the homescreen is visted
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Have the buttons find their IDs
        Button MSButton = findViewById(R.id.MobileShopping);
        Button DeptButton = findViewById(R.id.Departments);
       Button SpecButton = findViewById(R.id.Specials);
        Button  GGButton = findViewById(R.id.GiftGuide);
        Button GCButton = findViewById(R.id.GiftCards);
        Button ISButton = findViewById(R.id.InventorySystem);
        Button GDButton = findViewById(R.id.GetDirections);
        Button WFUButton = findViewById(R.id.WorkForUs);
        Button CUButton = findViewById(R.id.ContactUs);
        Button CartButton = findViewById(R.id.CartMain);
        //Go to the specials section to display items that are on sale and coupons
        //In this section the user can add items to their carts
       SpecButton.setOnClickListener(new View.OnClickListener() {
            /**
             * onClick will bring the user to the special section of the app
             * @param view
             */
            @Override
            public void onClick(View view) {
               Intent Specials = new Intent(MainActivity.this, Specials.class);
                startActivity(Specials);

            }
        });

        //Display a dummy MESSAGE for the section of the app that is not support.
        MSButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        DeptButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        GGButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        GCButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        ISButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        GDButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        WFUButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Display a dummy MESSAGE for the section of the app that is not support.
        CUButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will display a message informing the user that this section of the app is under construction
             * @param view
             */
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), DUMMYMESSAGE,Toast.LENGTH_LONG).show();

            }
        });
        //Allow the user to go to the cart from the home screen
        CartButton.setOnClickListener(new View.OnClickListener() {
            /**
             * Will bring the user to the shopping cart
             * @param view
             */
            @Override
            public void onClick(View view) {
                Intent Specials = new Intent(MainActivity.this, ShoppingCart.class);
                startActivity(Specials);

            }
        });



    }

    public void setContentView(int activity_main) {

    }
}